﻿namespace CalcFis.Properties
{
    internal class Resources
    {
    }
}