﻿namespace CalcFis
{
    partial class menu2ley
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.masacon = new System.Windows.Forms.Button();
            this.masavar = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // masacon
            // 
            this.masacon.BackColor = System.Drawing.Color.Transparent;
            this.masacon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.masacon.FlatAppearance.BorderSize = 0;
            this.masacon.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.masacon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.masacon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.masacon.Location = new System.Drawing.Point(41, 170);
            this.masacon.Name = "masacon";
            this.masacon.Size = new System.Drawing.Size(243, 30);
            this.masacon.TabIndex = 6;
            this.masacon.UseVisualStyleBackColor = false;
            this.masacon.Click += new System.EventHandler(this.masacon_Click);
            // 
            // masavar
            // 
            this.masavar.BackColor = System.Drawing.Color.Transparent;
            this.masavar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.masavar.FlatAppearance.BorderSize = 0;
            this.masavar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.masavar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.masavar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.masavar.Location = new System.Drawing.Point(41, 232);
            this.masavar.Name = "masavar";
            this.masavar.Size = new System.Drawing.Size(243, 30);
            this.masavar.TabIndex = 7;
            this.masavar.UseVisualStyleBackColor = false;
            this.masavar.Click += new System.EventHandler(this.masavar_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Location = new System.Drawing.Point(264, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(22, 24);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(288, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 34);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // menu2ley
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CalcFis.Properties.Resources.menu2ley;
            this.ClientSize = new System.Drawing.Size(325, 449);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.masavar);
            this.Controls.Add(this.masacon);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "menu2ley";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "menu2ley";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button masacon;
        private System.Windows.Forms.Button masavar;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}