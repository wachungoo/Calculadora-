﻿namespace CalcFis
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Gravedad = new System.Windows.Forms.Button();
            this.pita = new System.Windows.Forms.Button();
            this.dilatacion = new System.Windows.Forms.Button();
            this.newton1 = new System.Windows.Forms.Button();
            this.newton2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(42, 63);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(243, 34);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Gravedad
            // 
            this.Gravedad.BackColor = System.Drawing.Color.Transparent;
            this.Gravedad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Gravedad.FlatAppearance.BorderSize = 0;
            this.Gravedad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Gravedad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.Gravedad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Gravedad.Location = new System.Drawing.Point(42, 121);
            this.Gravedad.Name = "Gravedad";
            this.Gravedad.Size = new System.Drawing.Size(243, 51);
            this.Gravedad.TabIndex = 1;
            this.Gravedad.UseVisualStyleBackColor = false;
            this.Gravedad.Click += new System.EventHandler(this.Gravedad_Click);
            // 
            // pita
            // 
            this.pita.BackColor = System.Drawing.Color.Transparent;
            this.pita.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pita.FlatAppearance.BorderSize = 0;
            this.pita.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.pita.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.pita.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pita.Location = new System.Drawing.Point(42, 196);
            this.pita.Name = "pita";
            this.pita.Size = new System.Drawing.Size(243, 28);
            this.pita.TabIndex = 2;
            this.pita.UseVisualStyleBackColor = false;
            this.pita.Click += new System.EventHandler(this.pita_Click);
            // 
            // dilatacion
            // 
            this.dilatacion.BackColor = System.Drawing.Color.Transparent;
            this.dilatacion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dilatacion.FlatAppearance.BorderSize = 0;
            this.dilatacion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.dilatacion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.dilatacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dilatacion.Location = new System.Drawing.Point(42, 247);
            this.dilatacion.Name = "dilatacion";
            this.dilatacion.Size = new System.Drawing.Size(243, 54);
            this.dilatacion.TabIndex = 3;
            this.dilatacion.UseVisualStyleBackColor = false;
            this.dilatacion.Click += new System.EventHandler(this.dilatacion_Click);
            // 
            // newton1
            // 
            this.newton1.BackColor = System.Drawing.Color.Transparent;
            this.newton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.newton1.FlatAppearance.BorderSize = 0;
            this.newton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.newton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.newton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newton1.Location = new System.Drawing.Point(42, 322);
            this.newton1.Name = "newton1";
            this.newton1.Size = new System.Drawing.Size(243, 30);
            this.newton1.TabIndex = 4;
            this.newton1.UseVisualStyleBackColor = false;
            this.newton1.Click += new System.EventHandler(this.newton1_Click);
            // 
            // newton2
            // 
            this.newton2.BackColor = System.Drawing.Color.Transparent;
            this.newton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.newton2.FlatAppearance.BorderSize = 0;
            this.newton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.newton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.newton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newton2.Location = new System.Drawing.Point(42, 376);
            this.newton2.Name = "newton2";
            this.newton2.Size = new System.Drawing.Size(243, 30);
            this.newton2.TabIndex = 5;
            this.newton2.UseVisualStyleBackColor = false;
            this.newton2.Click += new System.EventHandler(this.newton2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(287, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 34);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Location = new System.Drawing.Point(263, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(22, 24);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::CalcFis.Properties.Resources.Menufor;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(324, 452);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.newton2);
            this.Controls.Add(this.newton1);
            this.Controls.Add(this.dilatacion);
            this.Controls.Add(this.pita);
            this.Controls.Add(this.Gravedad);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Gravedad;
        private System.Windows.Forms.Button pita;
        private System.Windows.Forms.Button dilatacion;
        private System.Windows.Forms.Button newton1;
        private System.Windows.Forms.Button newton2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}